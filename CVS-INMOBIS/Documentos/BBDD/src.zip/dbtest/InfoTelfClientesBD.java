package dbtest;

public class InfoTelfClientesBD extends InfoTelfBD{
  public InfoTelfClientesBD(InfoTelfBean  telfbean) {
    super(telfbean,"TTelfCliente");
  }

}