package dbtest;

public class RowNotFoundException {
  public RowNotFoundException() {
  }
}
