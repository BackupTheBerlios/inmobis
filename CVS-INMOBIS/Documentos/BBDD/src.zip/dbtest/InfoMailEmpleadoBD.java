package dbtest;

public class InfoMailEmpleadoBD extends InfoMailBD {
  public InfoMailEmpleadoBD (InfoMailBean  mailbean) {
   super(mailbean,"TMailEmpleados");
 }

}
