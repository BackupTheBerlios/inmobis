package dbtest;

public class RowExitsException {
  public RowExitsException() {
  }
}
