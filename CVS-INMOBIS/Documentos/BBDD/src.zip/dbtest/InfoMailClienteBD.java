package dbtest;

public class InfoMailClienteBD extends InfoMailBD {
  public InfoMailClienteBD (InfoMailBean  mailbean) {
   super(mailbean,"TMailCliente");
 }

}
