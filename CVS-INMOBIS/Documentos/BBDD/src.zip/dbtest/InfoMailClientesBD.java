package dbtest;

public class InfoMailClientesBD extends InfoMailBD {
  public InfoMailClientesBD(InfoMailBean mailbean) {
  super(mailbean,"TMailCliente");
  }

}