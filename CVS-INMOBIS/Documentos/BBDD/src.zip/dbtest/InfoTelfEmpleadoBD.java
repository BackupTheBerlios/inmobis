package dbtest;

public class InfoTelfEmpleadoBD extends InfoTelfBD{
  public InfoTelfEmpleadoBD (InfoTelfBean  telbean) {
  super(telbean,"TTelfCliente");
}

}
