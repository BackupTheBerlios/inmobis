package dbtest;

import java.util.*;
import java.*;
import javax.*;
import java.sql.*;
import util.*;


public class EmpleadoBD implements BDObject,GestorEmpleadoBD {
  private EmpleadoBean empleado;
  private InfoDirBean dirCliente;
  private InfoDirClientesBD direccion;
  private InfoTelfBean telfCliente;
  private InfoTelfClienteBD telefono;
  private InfoMailBean mailCliente;
  private InfoMailClienteBD mail;

  public EmpleadoBD(EmpleadoBean _empleado) {
    empleado = _empleado;
  }

  public Object getBean() {
    return empleado;
  }

  public InfoDirBean getDireccionBean (){

      return dirCliente;
    }

    public InfoTelfBean getTelefonoBean (){

     return telfCliente;
    }

    public InfoMailBean getMailBean (){

     return mailCliente;
    }

  public void select() {

    try {
      Connection conn = ConnectionManager.getConection();
      Statement stmt = conn.createStatement();
      ResultSet rs = null;

      rs = stmt.executeQuery("SELECT * FROM TEmpleado WHERE idEmpleado=" +
                             MysqlUtils.toMysqlString(empleado.getIdEmpleado()));

      if (rs.next()) {

        empleado.setIdEmpleado(rs.getString("idEmpleado"));
        empleado.setNombre(rs.getString("nombre"));
        empleado.setApellido1(rs.getString("apellido1"));
        empleado.setApellido2(rs.getString("apellido2"));
        empleado.setFechNacimiento(rs.getString("fechNacimiento"));

      }
    }
    catch (Exception ex) {
      System.out.println(ex);
    }

  }

  public void insert() {

    try {
      Connection conn = ConnectionManager.getConection();
      Statement stmt = conn.createStatement();
      ResultSet rs = null;

      StringBuffer sqlString = new StringBuffer("INSERT INTO TEmpleados ");
      sqlString.append("VALUES (" + MysqlUtils.toMysqlString(empleado.getIdEmpleado()) + ", ");
      sqlString.append(MysqlUtils.toMysqlString(empleado.getNombreEmpleado()) +
                       ", ");
      sqlString.append(MysqlUtils.toMysqlString(empleado.getApellido1()) + ", ");
      sqlString.append(MysqlUtils.toMysqlString(empleado.getApellido2()) + ", ");
      sqlString.append(MysqlUtils.toMysqlString(empleado.getFechNacimiento()) +
                       ")");

      stmt.execute(sqlString.toString());
    }
    catch (Exception ex) {
      System.out.println(ex);
    }
  }

  public void update() {

    try {
      Connection conn = ConnectionManager.getConection();
      Statement stmt = conn.createStatement();
      ResultSet rs = null;

      StringBuffer sqlString = new StringBuffer("UPDATE TEmpleados ");
      sqlString.append("set idEmpleado=" +
                       MysqlUtils.toMysqlString(empleado.getIdEmpleado()) + ", ");
      sqlString.append("nombre=" +
                       MysqlUtils.toMysqlString(empleado.getNombreEmpleado()) +
                       ", ");
      sqlString.append("apellido1=" +
                       MysqlUtils.toMysqlString(empleado.getApellido1()) + ", ");
      sqlString.append("apellido2=" +
                       MysqlUtils.toMysqlString(empleado.getApellido2()) + ", ");
      sqlString.append("fechNacimiento=" +
                       MysqlUtils.toMysqlString(empleado.getFechNacimiento()));
      sqlString.append("WHERE idEmpleado=" +
                       MysqlUtils.toMysqlString(empleado.getIdEmpleado()));
      stmt.execute(sqlString.toString());


         }
    catch (Exception ex) {
      System.out.println(ex);
    }

  }

  public void delete () {

    try {
      Connection conn = ConnectionManager.getConection();
      Statement stmt = conn.createStatement();
      ResultSet rs = null;

      StringBuffer sqlString = new StringBuffer("DELETE FROM TEmpleados ");
      sqlString.append("WHERE idCliente=" +
                      MysqlUtils.toMysqlString(empleado.getIdEmpleado()));
     stmt.execute(sqlString.toString());



    }
    catch (Exception ex) {
      System.out.println(ex);
    }

  }

  public String [] getIdDirecciones(){
      Vector direcciones=new Vector();
      StringBuffer query=new StringBuffer();
      query.append("SELECT idGeneral FROM TDirEmpleado WHERE idGeneral=");
      query.append(MysqlUtils.toMysqlString(empleado.getIdEmpleado()));

           try {
             Connection conn = ConnectionManager.getConection();
             Statement stmt = conn.createStatement();
             ResultSet rs=stmt.executeQuery(query.toString());
               while (rs.next()){
                direcciones.add(rs.getString("idGeneral"));
               }
             }
         catch (Exception e) {
          e.printStackTrace();
       }
      return ArrayOps.toStringArray(direcciones);
   }

   public InfoDirBean newInfoDirEmpleados(String descDir){
   InfoDirBean idb=new  InfoDirBean();
   idb.setIdGeneral(empleado.getIdEmpleado());
   idb.setDescDir(descDir);
   return idb;
   }
   public String [] getIdTelefonos(){
     Vector direcciones=new Vector();
     StringBuffer query=new StringBuffer();
     query.append("SELECT idGeneral FROM TTelfEmpleado WHERE idGeneral=");
     query.append(MysqlUtils.toMysqlString(empleado.getIdEmpleado()));

          try {
            Connection conn = ConnectionManager.getConection();
            Statement stmt = conn.createStatement();
            ResultSet rs=stmt.executeQuery(query.toString());
              while (rs.next()){
               direcciones.add(rs.getString("idGeneral"));
              }
            }
        catch (Exception e) {
         e.printStackTrace();
      }
     return ArrayOps.toStringArray(direcciones);
  }

  public InfoTelfBean newInfoTelfEmpleados(String desctelf){
  InfoTelfBean idb=new  InfoTelfBean();
  idb.setIdGeneral(empleado.getIdEmpleado());
  idb.setDescTelefono(desctelf);
  return idb;
  }

  public String [] getIdMails(){
     Vector direcciones=new Vector();
     StringBuffer query=new StringBuffer();
     query.append("SELECT idGeneral FROM TMailEmpleado WHERE idGeneral=");
     query.append(MysqlUtils.toMysqlString(empleado.getIdEmpleado()));

          try {
            Connection conn = ConnectionManager.getConection();
            Statement stmt = conn.createStatement();
            ResultSet rs=stmt.executeQuery(query.toString());
              while (rs.next()){
               direcciones.add(rs.getString("idGeneral"));
              }
            }
        catch (Exception e) {
         e.printStackTrace();
      }
     return ArrayOps.toStringArray(direcciones);
  }

  public InfoMailBean newInfoMailEmpleados(String descMail){
  InfoMailBean idb=new  InfoMailBean();
  idb.setIdGeneral(empleado.getIdEmpleado());
  idb.setDescMail(descMail);
  return idb;
  }
  public void consultaDir (String descDir){
    dirCliente=newInfoDirEmpleados(descDir);
    InfoDirEmpleadosBD direccion = new InfoDirEmpleadosBD(dirCliente);
    direccion.select();

  }

  public void consultaTelf (String descTelf){
   telfCliente=newInfoTelfEmpleados(descTelf);
   InfoTelfEmpleadosBD telefono = new InfoTelfEmpleadosBD(telfCliente);
   telefono.select();
  }

  public void consultaMail (String descMail){
  mailCliente=newInfoMailEmpleados(descMail);
  InfoMailEmpleadosBD mail = new InfoMailEmpleadosBD(mailCliente);
  mail.select();
  }


  public void deleteDir (String descDir){
    String [] direcciones = getIdDirecciones();

    dirCliente=newInfoDirEmpleados(descDir);
    InfoDirEmpleadosBD direccion = new InfoDirEmpleadosBD(dirCliente);
    direccion.delete();
  }

  public void deleteTelf (String descTel){
   String [] direcciones = getIdTelefonos();

   telfCliente=newInfoTelfEmpleados(descTel);
   InfoTelfEmpleadosBD telefono = new InfoTelfEmpleadosBD(telfCliente);
   telefono.delete();
  }

  public void deleteMail (String descMail){
  String [] mails = getIdMails();
  mailCliente=newInfoMailEmpleados(descMail);
  InfoMailEmpleadosBD mail = new InfoMailEmpleadosBD (mailCliente);
  mail.delete();
  }

  public void insertaDir (InfoDirBean miDireccion){

    InfoDirEmpleadosBD direccion = new InfoDirEmpleadosBD(miDireccion);
    dirCliente=miDireccion;
    direccion.insert();

  }

  public void insertaTelf (InfoTelfBean miTelefono){

   InfoTelfEmpleadosBD telefono=new InfoTelfEmpleadosBD (miTelefono);
   telfCliente=miTelefono;
   telefono.insert();

  }

  public void insertaMail (InfoMailBean miMail){

  InfoMailEmpleadosBD mail=new InfoMailEmpleadosBD (miMail);
  mailCliente=miMail;
  mail.insert();
  }

  public static void main(String[] args) {
   /* EmpleadoBD user = new EmpleadoBD();
    EmpleadoBean emp;
    // user.eliminaEmpleado("G543");
    emp = user.dameUsuario("Cristina");
    emp.setApellido1("Rivero");
    user.modificaUsuario(emp);
    System.out.println(emp.getIdEmpleado());
    System.out.println(emp.getNombreEmpleado());
    System.out.println(emp.getApellido1());
    System.out.println(emp.getApellido2());*/
  }

}
