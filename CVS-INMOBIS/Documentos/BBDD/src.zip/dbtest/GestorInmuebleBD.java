package dbtest;

public interface GestorInmuebleBD {
 Object getBean();
 InfoDirBean getDireccionBean ();
 void select () ;
 void insert() ;
 void update() ;
 void delete () ;
 String [] getIdDirecciones();
 InfoDirBean newInfoDirInmuebles(String descDir);
 void consultaDir (String descDir);
 void deleteDir (String descDir);
 void insertaDir (InfoDirBean miDireccion);


}
