package dbtest;

public class InfoDirEmpleadosBD extends InfoDirBD {

  public InfoDirEmpleadosBD (InfoDirBean  dirbean) {
   super(dirbean,"TDirEmpleados");
 }


}
