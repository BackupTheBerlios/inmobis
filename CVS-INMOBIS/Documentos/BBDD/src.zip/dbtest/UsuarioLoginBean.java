package dbtest;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class UsuarioLoginBean {

  protected String nombreUsuario;
  protected String password;
  protected String tipoUsuario;

  public String getNombreUsuario(){
    return nombreUsuario;
  }
  public String getPassword(){
    return password;
  }
  public String getTipoUsuario(){
    return tipoUsuario;
  }

  public void setPassword(String _password){
    this.password=_password;
  }
  public void setNombreUsuario(String _nombreUsuario) {
    this.nombreUsuario=_nombreUsuario;
  }
  public void setTipoUsuario(String _tipoUsuario){
    this.tipoUsuario=_tipoUsuario;
  }

}
