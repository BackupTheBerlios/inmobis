package dbtest;

import java.sql.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ConnectionManager {

//private static final String hostname="mysql4-I";
  private static final String hostname = "localhost";
  private static final String dbname = "inmobis";
//private static final String url="jdbc:mysql://"+hostname+"/"+dbname;
  private static final String url = "jdbc:mysql://" + hostname + "/" + dbname;
  private static Connection conn;
  private static Statement stmt;


  private static Connection newConnection(){
 Connection c=null;
   try {
       Class.forName("com.mysql.jdbc.Driver").newInstance();

       c = DriverManager.getConnection(url);
       System.out.println("Hola");

     }
     catch (Exception ex) {
       System.out.println(ex);
   }
   return c;
 }


  private static void initConnection(){

    try {
        Class.forName("com.mysql.jdbc.Driver").newInstance();

        conn = DriverManager.getConnection(url);
        conn.setAutoCommit(true);

      }
      catch (Exception ex) {
        System.out.println(ex);
    }
  }

  public static Connection getConection() {
    if (conn == null){
     initConnection();
    }
    return conn;
    //return newConnection();
  }



  public static void finishConnection(){
    try {
      conn.close();
     }
     catch (Exception ex) {
       System.out.println(ex);
   }

 }



}
