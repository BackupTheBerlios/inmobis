package dbtest;

public class InfoMailEmpleadosBD extends InfoMailBD {
  public InfoMailEmpleadosBD(InfoMailBean mailbean) {
  super(mailbean,"TMailEmpleado");
  }
}