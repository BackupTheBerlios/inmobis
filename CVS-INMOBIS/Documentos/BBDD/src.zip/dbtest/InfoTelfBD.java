package dbtest;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;

public class InfoTelfBD implements BDObject {

  private InfoTelfBean telefono;
  private String nombreTabla;

 public InfoTelfBD (InfoTelfBean _telefono, String _nombreTabla) {
   telefono = _telefono;
   nombreTabla=_nombreTabla;
 }

  public Object getBean() {
     return telefono;
   }

   public void select () {

      try {

        Connection conn = ConnectionManager.getConection();
        Statement stmt = conn.createStatement();
        ResultSet rs = null;

        rs = stmt.executeQuery("SELECT * FROM " + nombreTabla + " WHERE idGeneral =" +
                               MysqlUtils.toMysqlString(telefono.getIdGeneral())+"AND descTelefono ="+
                                MysqlUtils.toMysqlString(telefono.getDescTelefono()));
        if (rs.next()) {
          telefono.setIdGeneral(rs.getString("idGeneral"));
          telefono.setDescTelefono(rs.getString("descTelefono"));
          telefono.setTelefono(rs.getString("telefono"));
          telefono.setTelefono2(rs.getString("telefono2"));

        }


      }
      catch(Exception ex)
        {
         System.out.println(ex);
        }


   }

   public void insert() {

    try {
      Connection conn = ConnectionManager.getConection();
      Statement stmt = conn.createStatement();
      ResultSet rs = null;

      StringBuffer sqlString = new StringBuffer("INSERT INTO" + nombreTabla );
      sqlString.append("VALUES (" +  MysqlUtils.toMysqlString (telefono.getIdGeneral()) + ", ");
      sqlString.append(MysqlUtils.toMysqlString(telefono.getDescTelefono()) +", ");
      sqlString.append(MysqlUtils.toMysqlString(telefono.getTelefono()) + ", ");
      sqlString.append(MysqlUtils.toMysqlString(telefono.getTelefono2()) + ")");

      stmt.execute(sqlString.toString());
    }
    catch (Exception ex) {
      System.out.println(ex);
    }
  }

  public void update() {

    try {
      Connection conn = ConnectionManager.getConection();
      Statement stmt = conn.createStatement();
      ResultSet rs = null;

      StringBuffer sqlString = new StringBuffer("UPDATE" + nombreTabla );
      sqlString.append("set IdGeneral=" +
                       MysqlUtils.toMysqlString(telefono.getIdGeneral()) + ", ");
      sqlString.append("descTelefono=" +
                       MysqlUtils.toMysqlString(telefono.getDescTelefono()) +
                       ", ");
      sqlString.append("telefono=" +
                       MysqlUtils.toMysqlString(telefono.getTelefono()) + ", ");

      sqlString.append("telefono2=" +
                       MysqlUtils.toMysqlString(telefono.getTelefono2()));
      sqlString.append("WHERE IdGeneral=" +
                       MysqlUtils.toMysqlString(telefono.getIdGeneral())+"AND descTelefono="+
                                MysqlUtils.toMysqlString(telefono.getDescTelefono()));
      stmt.execute(sqlString.toString());


         }
    catch (Exception ex) {
      System.out.println(ex);
    }

  }

  public void delete () {

    try {
      Connection conn = ConnectionManager.getConection();
      Statement stmt = conn.createStatement();
      ResultSet rs = null;

      StringBuffer sqlString = new StringBuffer("DELETE FROM " +nombreTabla );
      sqlString.append(" WHERE idGeneral=" +
                       MysqlUtils.toMysqlString(telefono.getIdGeneral())+"AND descTelefono="+
                                MysqlUtils.toMysqlString(telefono.getDescTelefono()));
     stmt.execute(sqlString.toString());



    }
    catch (Exception ex) {
      System.out.println(ex);
    }

  }

}
