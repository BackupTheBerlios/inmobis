package dbtest;

public class InfoDirClientesBD extends InfoDirBD  {


public InfoDirClientesBD (InfoDirBean  dirbean) {
  super(dirbean,"TDirCliente");
}
}
