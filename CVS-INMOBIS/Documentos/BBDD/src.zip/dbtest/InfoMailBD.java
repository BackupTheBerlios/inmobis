package dbtest;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;

public class InfoMailBD implements BDObject {
  private InfoMailBean mail;
 private String nombreTabla;

public InfoMailBD (InfoMailBean _mail, String _nombreTabla) {
  mail = _mail;
  nombreTabla=_nombreTabla;
}

 public Object getBean() {
    return mail;
  }

  public void select () {

     try {

       Connection conn = ConnectionManager.getConection();
       Statement stmt = conn.createStatement();
       ResultSet rs = null;

       rs = stmt.executeQuery("SELECT * FROM "+ nombreTabla + " WHERE idGeneral=" +
                              MysqlUtils.toMysqlString(mail.getIdGeneral())+"AND descMail= "+
                               MysqlUtils.toMysqlString(mail.getDescMail()));
       if (rs.next()) {
         mail.setIdGeneral(rs.getString("idGeneral"));
         mail.setDirMail(rs.getString("dirMail"));
         mail.setDescMail(rs.getString("descMail"));


       }


     }
     catch(Exception ex)
       {
        System.out.println(ex);
       }


  }

  public void insert() {

   try {
     Connection conn = ConnectionManager.getConection();
     Statement stmt = conn.createStatement();
     ResultSet rs = null;

     StringBuffer sqlString = new StringBuffer("INSERT INTO" + nombreTabla );
     sqlString.append("VALUES (" + MysqlUtils.toMysqlString (mail.getIdGeneral()) + ", ");
     sqlString.append(MysqlUtils.toMysqlString(mail.getDirMail()) +", ");
     sqlString.append(MysqlUtils.toMysqlString(mail.getDescMail()) + ")");

     stmt.execute(sqlString.toString());
   }
   catch (Exception ex) {
     System.out.println(ex);
   }
 }

 public void update() {

   try {
     Connection conn = ConnectionManager.getConection();
     Statement stmt = conn.createStatement();
     ResultSet rs = null;

     StringBuffer sqlString = new StringBuffer("UPDATE" + nombreTabla );
     sqlString.append("set IdGeneral=" +
                      MysqlUtils.toMysqlString(mail.getIdGeneral()) + ", ");
     sqlString.append("dirMail=" +
                      MysqlUtils.toMysqlString(mail.getDirMail()) +
                      ", ");

     sqlString.append("descMail=" +
                      MysqlUtils.toMysqlString(mail.getDescMail()));
     sqlString.append("WHERE IdGeneral=" +
                      MysqlUtils.toMysqlString(mail.getIdGeneral())+"AND descMail="+
                               MysqlUtils.toMysqlString(mail.getDescMail()));
     stmt.execute(sqlString.toString());


        }
   catch (Exception ex) {
     System.out.println(ex);
   }

 }

 public void delete () {

   try {
     Connection conn = ConnectionManager.getConection();
     Statement stmt = conn.createStatement();
     ResultSet rs = null;

     StringBuffer sqlString = new StringBuffer("DELETE FROM " + nombreTabla );
     sqlString.append(" WHERE idGeneral=" +
                      MysqlUtils.toMysqlString(mail.getIdGeneral())+"AND descMail= "+
                               MysqlUtils.toMysqlString(mail.getDescMail()));
    stmt.execute(sqlString.toString());



   }
   catch (Exception ex) {
     System.out.println(ex);
   }

 }


}
