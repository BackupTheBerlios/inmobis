package dbtest;

public class InfoTelfClienteBD extends InfoTelfBD {
  public InfoTelfClienteBD (InfoTelfBean  telbean) {
 super(telbean,"TTelfEmpleado");
}

}
