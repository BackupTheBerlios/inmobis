package dbtest;
import java.util.*;

public class Pruebas {



  public static  void consultaCliente() {
    //Pasamos la m�nima informacion que repreenta a un cliente univocamente
    //A partir del identificador obtendremos sus datos. El identificador lo conseguimos
    ClienteBean cliente=new ClienteBean();
    //por el cuestionario JSP
    cliente.setIdCliente("C101");
    //AHora ya tenemos un JavaBean de cliente con sus atributo a null excepto
    //el identificador que le damos y podemos hacer la consulta a la base de datos
    //ClienteBD clienteBD = new ClienteBD(cliente);
    GestorClienteBD clienteBD = new ClienteBD(cliente);
  //este es el cliente que se corresponde con el identificador solicitado
    clienteBD.select();
    //Obtenemos las direcciones del cliente, si queremos mostrar esta informacion
    //adem�s de los datos personales
    String [] direcciones=clienteBD.getIdDirecciones();
    //Ya tenemos el Bean de las direcciones de la casa del cliente.
    //En este caso casa se corresponde con el campo DescDir, dato
    //obtenido por el formulario
   /* InfoDirBean dirCliente=clienteBD.newInfoDirClientes("casa");//Bean de las direcciones
    InfoDirBD direccion = new InfoDirBD(dirCliente,"TDirCliente");
    direccion.select();*/

   clienteBD.consultaDir("casa");
   clienteBD.consultaTelf("028");
   clienteBD.consultaMail("hotmail");
   InfoDirBean dir=clienteBD.getDireccionBean();
   InfoTelfBean telf=clienteBD.getTelefonoBean();
   InfoMailBean mail=clienteBD.getMailBean();

/*
    InfoTelfBean telfCliente=clienteBD.newInfoTelfClientes("280");//Bean de las direcciones
    InfoTelfBD telefono = new InfoTelfBD(telfCliente,"TTelfCliente");
    telefono.select();

    InfoMailBean mailCliente=clienteBD.newInfoMailClientes("hotmailC101");//Bean de las direcciones
    InfoMailBD mail = new InfoMailBD(mailCliente,"TMailCliente");
    mail.select();*/


   // System.out.println(dirCliente.getCalle());
    System.out.println(dir.getCalle());
    System.out.println(telf.getTelefono());
    System.out.println(mail.getDirMail());
  }

  public static void deleteCliente() {
    ClienteBean cliente=new ClienteBean();
    cliente.setIdCliente("C101");
    //ClienteBD clienteBD = new ClienteBD(cliente);
    GestorClienteBD clienteBD = new ClienteBD(cliente);
    clienteBD.delete();
    clienteBD.deleteDir("casa");
    clienteBD.deleteTelf("028");
    clienteBD.deleteMail("hotmail");


  }

  public static  void updateCliente() {
   //Pasamos la m�nima informacion que repreenta a un cliente univocamente
   //A partir del identificador obtendremos sus datos. El identificador lo conseguimos
   ClienteBean cliente=new ClienteBean();
   //por el cuestionario JSP
   cliente.setIdCliente("C107");
   //AHora ya tenemos un JavaBean de cliente con sus atributo a null excepto
   //el identificador que le damos y podemos hacer la consulta a la base de datos
  //  BDObject clienteBD = new ClienteBD(cliente);
  GestorClienteBD clienteBD = new ClienteBD (cliente);
   clienteBD.select();
   cliente.setNombre("Marta");
   clienteBD.update();

   //este es el cliente que se corresponde con el identificador solicitado

   System.out.println(cliente.getNombreCliente());
 }


  public static  void insertCliente() {

    ClienteBean cliente=new ClienteBean();
    InfoDirBean direccion=new InfoDirBean();

    //Construimos el JavaBEan con los datos que obtengamos de
    //los formularios JSP
    cliente.setIdCliente("C107");
    cliente.setNombre("Diana");
    cliente.setApellido1("Galvez");
    cliente.setApellido2("Yaguez");
    cliente.setFechNacimiento("2003-10-10");

    direccion.setIdGeneral(cliente.getIdCliente());
    direccion.setDescDir("casa");
    direccion.setCalle("Miro");
    direccion.setNum("1");
    direccion.setPiso("3�A");
    direccion.setCodPostal("28011");
    direccion.setPoblacion("Madrid");
    direccion.setProvincia("Madrid");
    direccion.setPais("Espa�a");



    //Una vez construido hacemos uso de la base de datos
    //ClienteBD clienteBD = new ClienteBD(cliente);
    GestorClienteBD clienteBD=new ClienteBD(cliente);
    //Y lo a�adimos a nuestra base de datos
    clienteBD.insert();
    clienteBD.insertaDir(direccion);
  }

 public static void main(String[] args) {
    Pruebas prueba= new Pruebas();
   //prueba.consultaCliente();
   prueba.insertCliente();
   //prueba.deleteCliente();
    // prueba.updateCliente();
 }
}
