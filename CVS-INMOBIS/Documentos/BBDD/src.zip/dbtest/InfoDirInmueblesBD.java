package dbtest;

public class InfoDirInmueblesBD extends InfoDirBD {
  public InfoDirInmueblesBD (InfoDirBean  dirbean) {
  super(dirbean,"TDirInmuebles");
}


}
