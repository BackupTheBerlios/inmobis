package dbtest;
import java.*;
import javax.*;
import java.sql.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class UsuarioLoginBD implements BDObject {
  private UsuarioLoginBean login;

 public UsuarioLoginBD (UsuarioLoginBean _login) {
   login = _login;
 }


 public Object getBean() {
    return login;
  }

  public void select () {

     try {

       Connection conn = ConnectionManager.getConection();
       Statement stmt = conn.createStatement();
       ResultSet rs = null;

       rs = stmt.executeQuery("SELECT * FROM TLogin WHERE nombreUsuario=" +
                              MysqlUtils.toMysqlString(login.getNombreUsuario()));
       if (rs.next()) {
         login.setNombreUsuario(rs.getString("nombreUsuario"));
         login.setPassword(rs.getString("password"));
         login.setTipoUsuario(rs.getString("tipoUsuario"));

       }


     }
     catch(Exception ex)
       {
        System.out.println(ex);
       }


  }

  public void insert() {

   try {
     Connection conn = ConnectionManager.getConection();
     Statement stmt = conn.createStatement();
     ResultSet rs = null;

     StringBuffer sqlString = new StringBuffer("INSERT INTO TLogin ");
     sqlString.append("VALUES (" +MysqlUtils.toMysqlString(login.getNombreUsuario()) + ", ");
     sqlString.append(MysqlUtils.toMysqlString(login.getPassword()) +
                      ", ");
     sqlString.append(MysqlUtils.toMysqlString(login.getTipoUsuario()) +
                      ")");

      stmt.execute(sqlString.toString());
   }
   catch (Exception ex) {
     System.out.println(ex);
   }
 }

 public void update() {

   try {
     Connection conn = ConnectionManager.getConection();
     Statement stmt = conn.createStatement();
     ResultSet rs = null;

     StringBuffer sqlString = new StringBuffer("UPDATE TLogin ");
     sqlString.append("set nombreUsuario=" +
                      MysqlUtils.toMysqlString(login.getNombreUsuario()) + ", ");
     sqlString.append("password=" +
                      MysqlUtils.toMysqlString(login.getPassword()) +
                      ", ");
     sqlString.append("tipoUsuario=" +
                      MysqlUtils.toMysqlString(login.getTipoUsuario()));
     sqlString.append("WHERE nombreUsuario=" +
                      MysqlUtils.toMysqlString(login.getNombreUsuario()));
     stmt.execute(sqlString.toString());


        }
   catch (Exception ex) {
     System.out.println(ex);
   }

 }

 public void delete () {

   try {
     Connection conn = ConnectionManager.getConection();
     Statement stmt = conn.createStatement();
     ResultSet rs = null;

     StringBuffer sqlString = new StringBuffer("DELETE FROM TLogin ");
     sqlString.append("WHERE nombreUsuario=" +
                     MysqlUtils.toMysqlString(login.getNombreUsuario()));
    stmt.execute(sqlString.toString());



   }
   catch (Exception ex) {
     System.out.println(ex);
   }

 }


}
