package dbtest;
import java.sql.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ConexionDB {

//private static final String hostname="mysql4-I";
private static final String hostname="localhost";
private static final String dbname="inmobis";
private static final String user="root";
private static final String password="alitor";
//private static final String url="jdbc:mysql://"+hostname+"/"+dbname;
private static final String url="jdbc:mysql://"+hostname+"/"+dbname;

  public ConexionDB() {

  }

  public static void main(String[] args){
    Connection conn = null;

          try
          {
             Class.forName("com.mysql.jdbc.Driver").newInstance();

             conn = DriverManager.getConnection(url,user,password);


             if (conn != null)
             {
                System.out.println("Conexi�n a base de datos "+url+" ... Ok");
                conn.close();
             }
          }
          catch(Exception ex)
          {
             System.out.println(ex);
          }

  }

}