package dbtest;

public interface BDObject {
   void select ();
   void insert ();
   void delete ();
   void update ();
   Object getBean();

}
