package dbtest;

public interface GestorClienteBD {
  Object getBean() ;
  InfoDirBean getDireccionBean ();
  InfoTelfBean getTelefonoBean ();
  InfoMailBean getMailBean ();
  void select() ;
  void insert() ;
  void update() ;
  void delete() ;
  String [] getIdDirecciones();
  InfoDirBean newInfoDirClientes(String descDir);
  String [] getIdTelefonos();
  InfoTelfBean newInfoTelfClientes(String desctelf);
  String [] getIdMails();
  InfoMailBean newInfoMailClientes(String descMail);
  void consultaDir (String descDir);
  void consultaTelf (String descTelf);
  void consultaMail (String descMail);
  void deleteDir (String descDir);
  void deleteTelf (String descTel);
  void deleteMail (String descMail);
  void insertaDir (InfoDirBean miDireccion);
  void insertaTelf (InfoTelfBean miTelefono);
  void insertaMail (InfoMailBean miMail);

}