package dbtest;

public class InfoTelfEmpleadosBD extends InfoTelfBD{

  public InfoTelfEmpleadosBD(InfoTelfBean  telfbean) {
    super(telfbean,"TTelfEmpleado");
  }

}
